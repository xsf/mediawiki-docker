DarkMode
========

A MediaWiki extension to add a toggleable dark mode for the MediaWiki user interface.

https://www.mediawiki.org/wiki/Extension:DarkMode

