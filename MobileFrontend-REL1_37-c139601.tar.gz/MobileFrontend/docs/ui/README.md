To generate UI documentation run `npm run storybook`
